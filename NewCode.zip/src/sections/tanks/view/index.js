export { default as TanksView } from './user-view';
